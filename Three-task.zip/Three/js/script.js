//menu active class when click

$(document).ready(function(){
    $(".main_navbar .menu li a").click(function(){
        $(".main_navbar .menu li a").removeClass("active"); 
        $(this).addClass("active");
    });
});

// for header fix while scrolling

$(window).scroll(function(){
    var sticky = $('.main_navbar'),
        scroll = $(window).scrollTop();

    if (scroll >= 30) sticky.addClass('fixed');
    else sticky.removeClass('fixed');
  });


// validation

function validatePhoneNumber(input_str) {
    var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

    return re.test(input_str);
}

function validateForm(event) {
    var phone = document.getElementById('contact-number').value;
    if (!validatePhoneNumber(phone)) {
        document.getElementById('number-error').classList.remove('hidden');
    } else {
        document.getElementById('number-error').classList.add('hidden');
        alert("validation success")
    }
    event.preventDefault();
}

document.getElementById('myform').addEventListener('submit', validateForm);